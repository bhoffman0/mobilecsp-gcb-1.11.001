var activity = [

  { questionType: 'freetext',
    questionHTML: 'Is there anything else you would need to have or know to teach this lesson effectively?',
    correctAnswerRegex: /white?/i,
    correctAnswerOutput: "Correct--Many charts, tables, and graphs have white backgrounds, so filtering for white images helps you find them faster.",
    incorrectAnswerOutput: "Try again. Consider what color would be dominant in images of charts, tables, and graphs. Look at the results above. Each of those sources is traditionally printed on paper.",
    showAnswerOutput: "Our search expert says: I would click on white in the color grid, since many charts, tables, and graphs have white backgrounds." 
  }

];