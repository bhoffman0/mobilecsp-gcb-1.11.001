
setupTable();
// sets up a rows x cols table of buttons
function setupTable() {
    var rows = parseInt(document.getElementById("rows").value);
    var cols = parseInt(document.getElementById("cols").value);
    var table = document.getElementById('grid');
    table.innerHTML = ""; //erase everything
    table.cellPadding = 0;
    table.cellSpacing = 0;
    for(r = 0; r < rows; r++) {
        var row = table.insertRow(r);
        for(c=0; c < cols; c++) {
            var cell = row.insertCell(c);
            cell.padding = 0;
            cell.style.padding = 0;
            cell.innerHTML = "<input type=button size=5 onClick='toggleButton(this)' style='background-color:white;width:100%'/>"; 
       }
    }
}
    
function toggleButton(btn) {
    if (btn.style.backgroundColor == "green")
        btn.style.backgroundColor = "white";
    else 
        btn.style.backgroundColor = "green";
}
